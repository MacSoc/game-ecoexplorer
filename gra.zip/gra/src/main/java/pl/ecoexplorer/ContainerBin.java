package pl.ecoexplorer;

import javafx.scene.Cursor;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;

public class ContainerBin {
    private final Button button;

    public ContainerBin(Pane root, double positionX, double positionY, String message,
                        ContainerBinClickListener containerBinClickListener) {
        this.button = new Button();
        this.button.setPrefHeight(140);
        this.button.setPrefWidth(95);
        this.button.setLayoutX(positionX);
        this.button.setLayoutY(positionY);
        this.button.setOpacity(0.0);
        this.button.setCursor(Cursor.HAND);

        root.getChildren()
            .add(this.button);
        this.button.setOnAction(e -> containerBinClickListener.onClick(message));
    }

    public double getX() {
        return this.button.getLayoutX();
    }

    public double getY() {
        return this.button.getLayoutY();
    }
}
