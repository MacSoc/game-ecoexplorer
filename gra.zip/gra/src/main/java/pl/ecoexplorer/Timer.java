package pl.ecoexplorer;

import javafx.animation.*;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.util.Duration;

public class Timer {
    private final Timeline timeline;
    private final Label timerLabel;
    private int durationMs;

    public Timer(Pane root) {
        this.timeline = new Timeline();
        this.durationMs = 0;

        this.timerLabel = new Label("Czas gry: 0s");
        timerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 28));
        timerLabel.setTextFill(Color.BLACK);
        timerLabel.setLayoutX(10);
        timerLabel.setLayoutY(10);
        root.getChildren()
            .add(timerLabel);
        init();
    }

    public void init() {
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.getKeyFrames().add(new KeyFrame(Duration.millis(10), event -> {
            durationMs += 10;
            updateLabel();
        }));
    }

    public void start() {
        timeline.play();
    }

    public void stop() {
        timeline.stop();
    }

    public void reset() {
        stop();
        durationMs = 0;
        updateLabel();
    }

    private void updateLabel() {
        timerLabel.setText("Czas gry: " + (durationMs / 1000) + "s");
    }

    public int getDuration() {
        return durationMs / 1000;
    }
}