package pl.ecoexplorer;

import javafx.animation.*;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.util.Duration;

public class MessageService {
    private final Label label;
    private final ImageView image;

    public MessageService(Pane root) {

        Image messageImage = new Image("message.png"); // Replace "car.png" with your image path
        image = new ImageView(messageImage);
        image.setFitHeight(170);
        image.setFitWidth(500);
        image.setLayoutX(125); // Adjust X position as needed
        image.setLayoutY(275); // Adjust Y position as needed
        image.setVisible(true);

        label = new Label("Bold Text");
        label.setMaxWidth(400);
        label.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        label.setLayoutX(200);
        label.setLayoutY(330);
        label.setWrapText(true);

        root.getChildren()
            .addAll(image, label);
    }

    public void showMessage(String targetText) {
        showMessage(targetText, () -> {});
    }

    public void showMessage(String targetText, FinishedListener finishedListener) {
        // Create a Timeline for the animation
        Timeline timeline = new Timeline();

        KeyFrame showKeyFrame0 = new KeyFrame(
            Duration.millis(0), // Adjust the delay as needed
            new KeyValue(image.visibleProperty(), true)
        );
        timeline.getKeyFrames().add(showKeyFrame0);

        KeyFrame showKeyFrame = new KeyFrame(
            Duration.millis(0), // Adjust the delay as needed
            new KeyValue(label.visibleProperty(), true)
        );
        timeline.getKeyFrames().add(showKeyFrame);

        // Add KeyFrames to update the text letter by letter
        for (int i = 0; i < targetText.length(); i++) {
            KeyFrame keyFrame = new KeyFrame(
                Duration.millis(i * 50), // Adjust the delay as needed
                new KeyValue(label.textProperty(), targetText.substring(0, i + 1))
            );
            timeline.getKeyFrames().add(keyFrame);
        }

        // Add a final KeyFrame to hide the label
        KeyFrame hideKeyFrame = new KeyFrame(
            Duration.millis(targetText.length() * 50 + 1000), // Adjust the delay as needed
            new KeyValue(label.visibleProperty(), false)
        );
        timeline.getKeyFrames().add(hideKeyFrame);

        // Add a final KeyFrame to hide the label
        KeyFrame hideKeyFrameLast = new KeyFrame(
            Duration.millis(targetText.length() * 50 + 1000), // Adjust the delay as needed
            new KeyValue(image.visibleProperty(), false)
        );
        timeline.getKeyFrames().add(hideKeyFrameLast);


        // Set the cycle count to 1 (play only once)
        timeline.setCycleCount(1);

        // Play the animation
        timeline.play();
        timeline.setOnFinished(actionEvent -> finishedListener.onFinish());
    }
}