package pl.ecoexplorer;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class EndGameDialog extends Dialog<Void> {

    public EndGameDialog(int scorePoints, int gameDuration,
                         FinishedScoreDialogListener finishedScoreDialogListener) {
        setTitle("Podsumowanie gry");

        Stage stage = (Stage) getDialogPane().getScene().getWindow();
        stage.getIcons().add(new Image("icon.jpeg"));

        initModality(Modality.APPLICATION_MODAL);

        Label scoreLabel = new Label("Liczba zdobytych punktów: " + scorePoints);
        scoreLabel.setFont(new Font(24));
        Label timeLabel = new Label("Czas gry: " + gameDuration + " s");
        timeLabel.setFont(new Font(24));
        Label nameLabel = new Label("Wpisz swoje imię");
        nameLabel.setFont(new Font(24));
        TextField nameTextField = new TextField();
        nameTextField.setFont(new Font(22));
        nameTextField.setAlignment(Pos.CENTER);

        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);

        VBox vbox = new VBox(10);
        vbox.setPadding(new Insets(20, 20, 20, 20));
        vbox.setAlignment(Pos.CENTER);
        vbox.getChildren().addAll(scoreLabel, timeLabel, spacer, nameLabel, nameTextField);

        getDialogPane().setContent(vbox);

        ButtonType okButton = new ButtonType("Zakończ", ButtonBar.ButtonData.OK_DONE);
        getDialogPane().getButtonTypes()
            .add(okButton);

        Node okNode = getDialogPane().lookupButton(okButton);
        okNode.setDisable(true);

        nameTextField.textProperty()
            .addListener((observable, oldValue, newValue) -> {
                okNode.setDisable(newValue.trim()
                    .isEmpty());
                if (newValue.length() > 10) {
                    nameTextField.setText(oldValue);
                }
            });

        setResultConverter(dialogButton -> {
            if (dialogButton == okButton) {
                finishedScoreDialogListener.onFinish(nameTextField.getText());
            }
            return null;
        });
    }
}