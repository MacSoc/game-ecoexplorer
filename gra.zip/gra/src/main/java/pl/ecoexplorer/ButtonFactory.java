package pl.ecoexplorer;

import javafx.scene.control.Button;

public class ButtonFactory {
    public static Button createSmallButton(String text) {
        Button button = new Button(text);
        button.setStyle(
            "-fx-background-color: white;" +
                "-fx-background-radius: 30px;" +
                "-fx-font-size: 20px;" +
                "-fx-font-weight: bold;"
        );
        button.setPrefHeight(50);
        button.setPrefWidth(125);
        return button;
    }

    public static Button createBigButton(String text) {
        Button button = new Button(text);
        button.setStyle(
            "-fx-background-color: white;" +
                "-fx-background-radius: 30px;" +
                "-fx-font-size: 24px;" +
                "-fx-font-weight: bold;"
        );
        button.setPrefHeight(75.0);
        button.setPrefWidth(300);
        return button;
    }
}
