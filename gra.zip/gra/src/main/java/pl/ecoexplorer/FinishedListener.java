package pl.ecoexplorer;

public interface FinishedListener {
    void onFinish();
}
