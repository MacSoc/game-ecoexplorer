package pl.ecoexplorer;

import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class ScoreCounter {
    private final Label scoreLabel;
    private final int maxScorePoints;
    private int sumOfScorePoints;

    public ScoreCounter(Pane root, int maxScorePoints) {

        this.scoreLabel = new Label();
        this.scoreLabel.setFont(Font.font("Arial", FontWeight.BOLD, 28));
        this.scoreLabel.setTextFill(Color.BLACK);
        this.scoreLabel.setLayoutX(10);
        this.scoreLabel.setLayoutY(65);
        this.maxScorePoints = maxScorePoints;
        root.getChildren()
            .add(this.scoreLabel);
        updateLabel();
    }

    public void addScore(int scorePoints) {
        this.sumOfScorePoints += scorePoints;
        updateLabel();
    }

    public void resetScore() {
        this.sumOfScorePoints = 0;
        updateLabel();
    }

    private void updateLabel() {
        this.scoreLabel.setText("Wynik: " + sumOfScorePoints + " / " + maxScorePoints);
    }

    public int getSumOfScorePoints() {
        return sumOfScorePoints;
    }
}