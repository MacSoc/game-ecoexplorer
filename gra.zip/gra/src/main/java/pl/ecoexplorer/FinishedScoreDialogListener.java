package pl.ecoexplorer;

public interface FinishedScoreDialogListener {
    void onFinish(String name);
}
