package pl.ecoexplorer;

public class ScoreEntry {
    private final String date;
    private final String name;
    private final int scorePoints;
    private final int gameDuration;

    public ScoreEntry(String date, String name, int scorePoints, int gameDuration) {
        this.date = date;
        this.name = name;
        this.scorePoints = scorePoints;
        this.gameDuration = gameDuration;
    }

    public String getDate() {
        return date;
    }

    public String getName() {
        return name;
    }

    public int getScorePoints() {
        return scorePoints;
    }

    public int getGameDuration() {
        return gameDuration;
    }
}
