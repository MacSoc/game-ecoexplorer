package pl.ecoexplorer;

public class Main {

    public static void main(String[] args) {
        GameApplication.main(args);
    }
}
