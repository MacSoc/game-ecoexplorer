package pl.ecoexplorer;

import javafx.scene.layout.Pane;

import java.util.List;

public class Game implements TrashMoveListener, ContainerBinClickListener {
    private final ScoreContainer scoreContainer = new ScoreContainer();
    private final MessageService messageService;
    private final FinishedListener finishedListener;
    private final List<Trash> trashes;
    private final Timer timer;
    private final ScoreCounter scoreCounter;
    private boolean isGameStarted = false;
    private boolean isGamePaused = false;
    private int trashCompletedCounter = 0;

    public Game(Pane root, MessageService messageService, FinishedListener finishedListener) {
        this.messageService = messageService;
        this.finishedListener = finishedListener;
        int firstContainerX = 870;
        int firstContainerY = 680;
        ContainerBin blue = new ContainerBin(root, firstContainerX, firstContainerY,
            "Kubeł niebieski jest do wrzucania papieru", this);
        ContainerBin yellow = new ContainerBin(root, firstContainerX + 95, firstContainerY,
            "Kubeł żółty jest do wrzucania plastiku i metalu", this);
        ContainerBin green = new ContainerBin(root, firstContainerX + 190, firstContainerY,
            "Kubeł zielony jest do wrzucania szkła", this);
        ContainerBin red = new ContainerBin(root, firstContainerX + 285, firstContainerY,
            "Kubeł czarny jest do wrzucania odpadów BIO", this);

        this.trashes = List.of(
            new Trash("banana.png", root, 129, 743, 30, red, this),
            new Trash("banana.png", root, 48, 689, 30, red, this),
            new Trash("watermelon.png", root, 612, 690, 30, red, this),
            new Trash("paper.png", root, 1105, 853, 50, blue, this),
            new Trash("paper.png", root, 88, 972, 50, blue, this),
            new Trash("glass.png", root, 540, 600, 80, green, this),
            new Trash("glass.png", root, 1077, 560, 80, green, this),
            new Trash("glass.png", root, 1103, 560, 80, green, this),
            new Trash("glass.png", root, 1130, 560, 80, green, this),
            new Trash("bottle.png", root, 61, 600, 100, yellow, this),
            new Trash("bottle.png", root, 624, 616, 100, yellow, this),
            new Trash("can.png", root, 779, 712, 150, yellow, this)
        );

        this.timer = new Timer(root);
        this.scoreCounter = new ScoreCounter(root, trashes.stream()
            .mapToInt(Trash::getScore)
            .sum());
    }

    public void reset() {
        messageService.showMessage("Posprzątaj miasto\n   CZAS START!", this::onStartGame);
        trashes.forEach(trash -> {
            trash.reset();
            trash.lock();
        });
        timer.stop();
        timer.reset();
        scoreCounter.resetScore();
        isGameStarted = false;
        isGamePaused = false;
    }

    public void pause() {
        isGamePaused = true;
        timer.stop();
        trashes.forEach(Trash::lock);
    }

    public void runAfterPause() {
        isGamePaused = false;
        timer.start();
        trashes.forEach(Trash::unlock);
    }

    public void stop() {
        pause();
        EndGameDialog endGameDialog = new EndGameDialog(scoreCounter.getSumOfScorePoints(),
            timer.getDuration(), name -> {
            scoreContainer.addEntry(name, scoreCounter.getSumOfScorePoints(), timer.getDuration());
            finishedListener.onFinish();
        });
        endGameDialog.showAndWait();
    }

    @Override
    public void onMove(boolean movingToTrash, int scorePoints) {
        if (movingToTrash) {
            trashCompletedCounter++;
            scoreCounter.addScore(scorePoints);
            messageService.showMessage("Super!!\nZdobywasz " + scorePoints + " punktów");
        } else {
            scoreCounter.addScore(-scorePoints);
            messageService.showMessage("Niestety, niepoprawny kubeł!!\nSpróbuj jeszcze raz");
        }

        if (trashCompletedCounter == trashes.size()) {
            stop();
        }
    }

    private void onStartGame() {
        trashCompletedCounter = 0;
        timer.start();
        trashes.forEach(Trash::unlock);
        isGameStarted = true;
    }

    public boolean isGameStarted() {
        return isGameStarted;
    }

    public boolean isGamePaused() {
        return isGamePaused;
    }

    public ScoreContainer getScoreContainer() {
        return scoreContainer;
    }

    @Override
    public void onClick(String message) {
        messageService.showMessage(message);
    }
}