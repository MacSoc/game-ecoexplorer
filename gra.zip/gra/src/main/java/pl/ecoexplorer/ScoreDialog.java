package pl.ecoexplorer;

import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.util.List;

public class ScoreDialog extends Dialog<Void> {

    public ScoreDialog(List<ScoreEntry> scoreEntries) {
        setTitle("Tablica wyników");
        initModality(Modality.APPLICATION_MODAL);

        Stage stage = (Stage) getDialogPane().getScene().getWindow();
        stage.getIcons().add(new Image("icon.jpeg"));

        VBox vbox = createVBox(scoreEntries);
        getDialogPane().setContent(vbox);

        ButtonType okButton = new ButtonType("Zamknij", ButtonBar.ButtonData.OK_DONE);
        getDialogPane().getButtonTypes().add(okButton);
    }

    private VBox createVBox(List<ScoreEntry> scoreEntries) {
        VBox vbox = new VBox(10);
        vbox.setPadding(new Insets(20, 20, 20, 20));
        vbox.setPrefWidth(600);
        vbox.setAlignment(Pos.CENTER);

        ListView<ScoreEntry> listView = new ListView<>(FXCollections.observableList(scoreEntries));
        listView.setCellFactory(new Callback<>() {
            @Override
            public ListCell<ScoreEntry> call(ListView<ScoreEntry> param) {
                return new ListCell<>() {
                    @Override
                    protected void updateItem(ScoreEntry entry, boolean empty) {
                        super.updateItem(entry, empty);
                        if (empty || entry == null) {
                            setText(null);
                        } else {
                            setText(entry.getDate() + " - " + entry.getName() + " - Punkty: " +
                                entry.getScorePoints() + " - Czas gry: " + entry.getGameDuration() + " ");
                            setFont(new Font(14));
                        }
                    }
                };
            }
        });

        vbox.getChildren().addAll(listView);

        return vbox;
    }
}