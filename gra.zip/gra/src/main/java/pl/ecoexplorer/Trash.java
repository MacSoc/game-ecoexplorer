package pl.ecoexplorer;

import javafx.scene.Cursor;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;

public class Trash {
    private final int defaultPositionX, defaultPositionY;
    private final int scorePoints;
    private final ImageView imageView;

    public Trash(String fileName, Pane root, int defaultPositionX, int defaultPositionY, int scorePoints,
                 ContainerBin targetContainer, TrashMoveListener trashMoveListener) {
        this.defaultPositionX = defaultPositionX;
        this.defaultPositionY = defaultPositionY;
        this.imageView = new ImageView(new Image(fileName));
        this.imageView.setFitHeight(65);
        this.imageView.setFitWidth(65);
        this.imageView.setLayoutX(defaultPositionX);
        this.imageView.setLayoutY(defaultPositionY);
        this.imageView.setCursor(Cursor.OPEN_HAND);
        this.scorePoints = scorePoints;

        root.getChildren()
            .add(this.imageView);

        init(targetContainer, trashMoveListener);
    }

    private void init(ContainerBin targetContainer, TrashMoveListener trashMoveListener) {
        this.imageView.setOnMouseDragged(event -> {
            this.imageView.setLayoutX(event.getSceneX() - (this.imageView.getFitHeight() / 2));
            this.imageView.setLayoutY(event.getSceneY() - (this.imageView.getFitWidth() / 2));
        });

        imageView.setOnMouseReleased(mouseEvent -> {
            boolean yOk = mouseEvent.getSceneY() >= (targetContainer.getY() - 50) &&
                mouseEvent.getSceneY() <= (targetContainer.getY() + 150);
            boolean xOk = mouseEvent.getSceneX() >= (targetContainer.getX()) &&
                mouseEvent.getSceneX() <= (targetContainer.getX() + 100);
            boolean positionOk = xOk && yOk;

            if (positionOk) {
                hide();
                trashMoveListener.onMove(true, scorePoints);
            } else {
                reset();
                trashMoveListener.onMove(false, scorePoints);
            }
        });
    }

    public void reset() {
        this.imageView.setVisible(true);
        this.imageView.setLayoutX(defaultPositionX);
        this.imageView.setLayoutY(defaultPositionY);
    }

    public void lock() {
        this.imageView.setDisable(true);
    }

    public void unlock() {
        this.imageView.setDisable(false);
    }

    public void hide() {
        this.imageView.setVisible(false);
    }

    public int getScore() {
        return this.scorePoints;
    }
}
