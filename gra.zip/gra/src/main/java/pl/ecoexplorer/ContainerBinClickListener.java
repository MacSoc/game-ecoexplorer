package pl.ecoexplorer;

public interface ContainerBinClickListener {
    void onClick(String message);
}
