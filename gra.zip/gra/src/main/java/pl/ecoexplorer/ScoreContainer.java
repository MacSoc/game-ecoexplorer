package pl.ecoexplorer;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class ScoreContainer {
    private final List<ScoreEntry> entries = new ArrayList<>();

    public void addEntry(String name, int scorePoints, int gameDuration) {
        this.entries.add(new ScoreEntry(nowAsString(), name, scorePoints, gameDuration));
    }

    public List<ScoreEntry> getEntries() {
        return entries;
    }

    public String nowAsString() {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return now.format(formatter);
    }
}
