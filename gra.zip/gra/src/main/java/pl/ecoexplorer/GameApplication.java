package pl.ecoexplorer;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class GameApplication extends Application {
    public static void main(String[] args) {
        launch();
    }

    @Override
    public void start(Stage stage) {
        Pane root = new Pane();
        ImageView backgroundImageView = new ImageView(new Image("background.png"));
        backgroundImageView.setFitWidth(1280);
        backgroundImageView.setFitHeight(1024);

        Button pauseButton = ButtonFactory.createSmallButton("Pauza");
        pauseButton.setLayoutX(1140);
        pauseButton.setLayoutY(20);

        Button endButton = ButtonFactory.createSmallButton("Zakończ");
        endButton.setLayoutX(1140);
        endButton.setLayoutY(80);

        root.getChildren()
            .addAll(backgroundImageView, pauseButton, endButton);

        Button newGameButton = ButtonFactory.createBigButton("Nowa gra");
        Button scoresButton = ButtonFactory.createBigButton("Tablica wyników");
        Button exitButton = ButtonFactory.createBigButton("Wyjście");

        Scene scene = new Scene(root, 1280, 1024);
        stage.setTitle("Nowa gra");
        Image icon = new Image("icon.jpeg");
        stage.getIcons()
            .add(icon);

        VBox buttonBox = new VBox(10);
        buttonBox.getChildren()
            .addAll(newGameButton, scoresButton, exitButton);
        buttonBox.setAlignment(javafx.geometry.Pos.CENTER);

        Image backgroundImage = new Image("background_menu.png");
        BackgroundImage backgroundImg = new BackgroundImage(backgroundImage, null, null, null, null);
        Background background = new Background(backgroundImg);

        BorderPane menuPane = new BorderPane();
        menuPane.setCenter(buttonBox);
        menuPane.setBackground(background);
        Scene menuScene = new Scene(menuPane, 1280, 1024);
        stage.setTitle("Eco explorer v1.0");
        stage.setScene(menuScene);
        stage.show();

        MessageService messageService = new MessageService(root);
        Game game = new Game(root, messageService, () -> stage.setScene(menuScene));

        newGameButton.setOnAction(e -> {
            game.reset();
            stage.setScene(scene);
            pauseButton.setText("Pauza");
        });

        exitButton.setOnAction(e -> Platform.exit());

        pauseButton.setOnAction(e -> {
            if (game.isGameStarted() && game.isGamePaused()) {
                game.runAfterPause();
                pauseButton.setText("Pauza");
            } else if (game.isGameStarted() && !game.isGamePaused()) {
                game.pause();
                pauseButton.setText("Wznów");
            }
        });

        scoresButton.setOnAction(actionEvent -> {
            ScoreDialog scoreDialog = new ScoreDialog(game.getScoreContainer().getEntries());
            scoreDialog.showAndWait();
        });

        endButton.setOnAction(e -> {
            if (game.isGameStarted()) {
                game.stop();
            } else {
                stage.setScene(menuScene);
            }
        });
    }
}