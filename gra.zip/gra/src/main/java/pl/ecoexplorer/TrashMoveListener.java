package pl.ecoexplorer;

public interface TrashMoveListener {
    void onMove(boolean movingToTrash, int scorePoints);
}
